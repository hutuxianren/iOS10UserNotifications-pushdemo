//
//  NotificationService.h
//  NotificationService
//
//  Created by Dely on 16/9/23.
//  Copyright © 2016年 Dely. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
