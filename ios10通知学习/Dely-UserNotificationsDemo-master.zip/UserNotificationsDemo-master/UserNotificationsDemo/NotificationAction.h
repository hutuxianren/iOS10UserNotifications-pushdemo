//
//  NotificationAction.h
//  UserNotificationsDemo
//
//  Created by Dely on 16/10/8.
//  Copyright © 2016年 Dely. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NotificationAction : NSObject

+ (void)addNotificationAction;
+ (void)addNotificationAction2;

@end
